package agents;

import domain.Agent;
import market.Market;

public class RawAluminiumSupplier extends Agent {

  public RawAluminiumSupplier(int thinkingTimeInMillis, Market market) {
    super(thinkingTimeInMillis, market);
  }

  @Override
  public void doAction() {
    // TODO Q2
  }
}
