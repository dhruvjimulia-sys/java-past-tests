package agents;

import domain.Agent;
import market.Market;

public class RawGlassSupplier extends Agent {

  public RawGlassSupplier(int thinkingTimeInMillis, Market market) {
    super(thinkingTimeInMillis, market);
  }

  @Override
  public void doAction() {
    // TODO Q2
  }
}
