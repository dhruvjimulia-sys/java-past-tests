package agents;

import domain.Agent;
import market.Market;

public class LaptopManufacturer extends Agent {

  public LaptopManufacturer(int thinkingTimeInMillis, Market market) {
    super(thinkingTimeInMillis, market);
  }

  @Override
  public void doAction() {
    // TODO Q2
  }
}
