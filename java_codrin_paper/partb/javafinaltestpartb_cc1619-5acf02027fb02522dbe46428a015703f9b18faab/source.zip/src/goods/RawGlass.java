package goods;

import domain.producttypes.RawMaterial;

public class RawGlass extends RawMaterial {

  public RawGlass(Origin origin) {
    super(origin);
  }
}
