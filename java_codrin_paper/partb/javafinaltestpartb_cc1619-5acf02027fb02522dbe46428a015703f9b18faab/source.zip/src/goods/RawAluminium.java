package goods;

import domain.producttypes.RawMaterial;

public class RawAluminium extends RawMaterial {

  public RawAluminium(Origin origin) {
    super(origin);
  }
}
