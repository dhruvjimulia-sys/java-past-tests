package testutils;

import domain.producttypes.ExchangeableGood;

public class MockProduct extends ExchangeableGood {}
