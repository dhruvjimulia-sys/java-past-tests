package generators;

public class Pair<S, T> {}
